CP/M Player for Win32 console
								11/28/2012

----- What's this

This is CP/M emulator running on Win32 command prompt.


----- How to use

Start command prompt and run this emulator with target command file
and any options.

For example compiling sample.c with Small-C:

	> CPM CC SAMPLE.C

Current directory is recognized as A drive.
To use B-P drive, create the dierctory named B-Z.


----------------------------------------
TAKEDA, toshiya
t-takeda@m1.interq.or.jp
http://homepage3.nifty.com/takeda-toshiya/
