/*      SETATT.C        for Small-C
---------------------------------------------------------------------------
        char setatt(char *name, char *attrb)

�@�\ ... �t�@�C���̑�����ύX����D
���� ...  name = �t�@�C�����i*,? �̎g�p�s�\�j
          attrb = ����   "R/W", "R/O", "DIR", "SYS"
�o�� ...  NULL/Complete    ERR/�G���[

                since  11-Feb-89, (C) FUTURE FORUM
		last   20-Oct-89
---------------------------------------------------------------------------
*/
#include        <stdio.h>
#define NOCCARGC                /* �����̌���n���Ȃ� */

extern char zzbuf;
static char att[4];
static char fcb[36];		/* FCB buffer */

setatt(name,attrb)      char *name,*attrb;      {
        int  i;
        char *ptr;

        for (i=0; i<3; ++i)     att[i] = toupper(attrb[i]);
        att[3] = NULL;
        if (fcbx(fcb,name)==ERR)       return(ERR);
        i = bdos(17,fcb);
        if (i==EOF)     return(ERR);
        ptr = &zzbuf + i*32;
        memcpy(fcb,ptr,12);

        if (strcmp(att,"R/W")==0)       fcb[9] &= 0x7F;
        else if (strcmp(att,"R/O")==0)  fcb[9] |= 0x80;
        else if (strcmp(att,"DIR")==0)  fcb[10] &= 0x7F;
        else if (strcmp(att,"SYS")==0)  fcb[10] |= 0x80;
        else            return(ERR);
        if (bdos(30,fcb)==EOF)         return(ERR);
        return(NULL);
        }
