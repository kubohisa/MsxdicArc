/*
** add primary and secondary registers (result in primary)
*/
ffadd() {ol("\tDAD\tD");}		/*A08*/

/*
** subtract primary from secondary register (result in primary)
*/
ffsub() {ffcall("CCSUB##");}

/*
** multiply primary and secondary registers (result in primary)
*/
ffmult() {ffcall("CCMULT##");}

/*
** divide secondary by primary register
** (quotient in primary, remainder in secondary)
*/
ffdiv() {ffcall("CCDIV##");}

/*
** remainder of secondary/primary
** (remainder in primary, quotient in secondary)
*/
ffmod() {ffdiv();swap();}

/*
** inclusive "or" primary and secondary registers
** (result in primary)
*/
ffor() {ffcall("CCOR##");}

/*
** exclusive "or" the primary and secondary registers
** (result in primary)
*/
ffxor() {ffcall("CCXOR##");}

/*
** "and" primary and secondary registers
** (result in primary)
*/
ffand() {ffcall("CCAND##");}

/*
** logical negation of primary register
*/
lneg() {ffcall("CCLNEG##");}

/*
** arithmetic shift right secondary register
** number of bits given in primary register
** (result in primary)
*/
ffasr() {ffcall("CCASR##");}

/*
** arithmetic shift left secondary register
** number of bits given in primary register
** (result in primary)
*/
ffasl() {ffcall("CCASL##");}

/*
** two's complement primary register
*/
neg() {ffcall("CCNEG##");}

/*
** one's complement primary register
*/
com() {ffcall("CCCOM##");}

/*
** multi dimensional array index generater		fas 2.6
*/

getmd(mdval) int mdval;{
  push();		/* save sum  			fas 2.6 */
  immed();		/* LXI H,			fas 2.6 */
  outdec(mdval);	/*   with index			fas 2.6 */
  nl();			/*				fas 2.6 */
  ffmult();		/* multiply by subscript	fas 2.6 */
  pop();		/* retrieve sum			fas 2.6 */
}

/*
** increment primary register by one object of whatever size
*/
inc(n) int n; {
  while(1) {
    ol("\tINX\tH");			/*A08*/
    if(--n < 1) break;
    }
  }

/*
** decrement primary register by one object of whatever size
*/
dec(n) int n; {
  while(1) {
    ol("\tDCX\tH");			/*A08*/
    if(--n < 1) break;
    }
  }
 
/*
** test for equal to
*/
ffeq()  {ffcall("CCEQ##");}

/*
** test for equal to zero
*/
eq0(label) int label; {
  ol("\tMOV\tA,H");		/*A08*/
  ol("\tORA\tL");		/*A08*/
  ot("\tJNZ\t");		/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for not equal to
*/
ffne()  {ffcall("CCNE##");}

/*
** test for not equal to zero
*/
ne0(label) int label; {
  ol("\tMOV\tA,H");		/*A08*/
  ol("\tORA\tL");		/*A08*/
  ot("\tJZ\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for less than (signed)
*/
fflt()  {ffcall("CCLT##");}

/*
** test for less than to zero
*/
lt0(label) int label; {
  ol("\tXRA\tA");		/*A08*/
  ol("\tORA\tH");		/*A08*/
  ot("\tJP\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for less than or equal to (signed)
*/
ffle()  {ffcall("CCLE##");}

/*
** test for less than or equal to zero
*/
le0(label) int label; {
  ol("\tMOV\tA,H");		/*A08*/
  ol("\tORA\tL");		/*A08*/
  ol("\tJZ\t$+8");		/*A08*/
  ol("\tXRA\tA");		/*A08*/
  ol("\tORA\tH");		/*A08*/
  ot("\tJP\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for greater than (signed)
*/
ffgt()  {ffcall("CCGT##");}

/*
** test for greater than to zero
*/
gt0(label) int label; {
  ol("\tXRA\tA");		/*A08*/
  ol("\tORA\tH");		/*A08*/
  ot("\tJM\t");			/*A08*/
  printlabel(label);
  nl();
  ol("\tORA\tL");		/*A08*/
  ot("\tJZ\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for greater than or equal to (signed)
*/
ffge()  {ffcall("CCGE##");}

/*
** test for gteater than or equal to zero
*/
ge0(label) int label; {
  ol("\tXRA\tA");		/*A08*/
  ol("\tORA\tH");		/*A08*/
  ot("\tJM\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for less than (unsigned)
*/
ult()  {ffcall("CCULT##");}

/*
** test for less than to zero (unsigned)
*/
ult0(label) int label; {
  ot("\tJMP\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test for less than or equal to (unsigned)
*/
ule()  {ffcall("CCULE##");}

/*
** test for greater than (unsigned)
*/
ugt()  {ffcall("CCUGT##");}

/*
** test for greater than or equal to (unsigned)
*/
uge()  {ffcall("CCUGE##");}

#ifdef OPTIMIZE
peephole(ptr) char *ptr; {
  while(*ptr) {
    if(streq(ptr,"\tLXI\tH,0\n\tDAD\tSP\n\tCALL\tCCGINT##")) {	/*A08*/
      if(streq(ptr+32, "\tXCHG;;")) {pp2();ptr=ptr+40;}		/*A08*/
      else                        {pp1();ptr=ptr+32;}		/*A08*/
      }
    else if(streq(ptr,"\tLXI\tH,2\n\tDAD\tSP\n\tCALL\tCCGINT##")) {  /*A08*/
      if(streq(ptr+32, "\tXCHG;;")) {pp3(pp2);ptr=ptr+40;}	/*A08*/
      else                        {pp3(pp1);ptr=ptr+32;}	/*A08*/
      }
    else if(optimize) {
      if(streq(ptr, "\tDAD\tSP\n\tCALL\tCCGINT##")) {		/*A08*/
        ol("\tCALL\tCCDSGI##");					/*A08*/
        ptr=ptr+23;						/*A08*/
        }
      else if(streq(ptr, "\tDAD\tD\n\tCALL\tCCGINT##")) {	/*A08*/
        ol("\tCALL\tCCDDGI##");					/*A08*/
        ptr=ptr+22;						/*A08*/
        }
      else if(streq(ptr, "\tDAD\tSP\n\tCALL\tCCGCHAR##")) {	/*A08*/
        ol("\tCALL\tCCDSGC##");					/*A08*/
        ptr=ptr+24;						/*A08*/
          }
      else if(streq(ptr, "\tDAD\tD\n\tCALL\tCCGCHAR##")) {	/*A08*/
        ol("\tCALL\tCCDDGC##");					/*A08*/
        ptr=ptr+23;						/*A08*/
        }
      else if(streq(ptr,
"\tDAD\tSP\n\tMOV\tD,H\n\tMOV\tE,L\n\tCALL\tCCGINT##\n\tINX\tH\n\tCALL\tCCPINT##")) {
						/*A08*/
        ol("CALL\tCCINCI##");			/*A08*/
        ptr=ptr+63;				/*A08*/
        }
      else if(streq(ptr,
"\tDAD\tSP\n\tMOV\tD,H\n\tMOV\tE,L\n\tCALL\tCCGINT##\n\tDCX\tH\n\tCALL\tCCPINT##")) {
						/*A08*/
        ol("\tCALL\tCCDECI##");			/*A08*/
        ptr=ptr+63;				/*A08*/
        }
      else if(streq(ptr,
"\tDAD\tSP\n\tMOV\tD,H\n\tMOV\tE,L\n\tCALL\tCCGCHAR##\n\tINX\tH\n\tMOV\tA,L\n\tSTAX\tD")) {
						/*A08*/
        ol("\tCALL\tCCINCC##");			/*A08*/
        ptr=ptr+66;				/*A08*/
        }
      else if(streq(ptr,
"\tDAD\tSP\n\tMOV\tD,H\n\tMOV\tE,L\n\tCALL\tCCGCHAR##\n\tDCX\tH\n\tMOV\tA,L\n\tSTAX\tD")) {
						/*A08*/
        ol("\tCALL\tCCDECC##");			/*A08*/
        ptr=ptr+66;				/*A08*/
        }
      else if(streq(ptr, "\tDAD\tD\n\tPOP\tD\n\tCALL\tCCPINT##")) {  /*A08*/
        ol("\tCALL\tCDPDPI##");			/*A08*/
        ptr=ptr+29;				/*A08*/
        }
      else if(streq(ptr, "\tDAD\tD\n\tPOP\tD\n\tMOV\tA,L\n\tSTAX\tD")) {
						/*A08*/
        ol("\tCALL\tCDPDPC##");			/*A08*/
        ptr=ptr+31;				/*A08*/
        }
      else if(streq(ptr, "\tPOP\tD\n\tCALL\tCCPINT##")) {	/*A08*/
        ol("\tCALL\tCCPDPI##");					/*A08*/
        ptr=ptr+22;						/*A08*/
        }
                                                 /*30*/
      /* additional optimizing logic goes here */
      else cout(*ptr++, output);
      }
    else cout(*ptr++, output);
    }
  }

pp1() {
  ol("\tPOP\tH");		/*A08*/
  ol("\tPUSH\tH");		/*A08*/
  }

pp2() {
  ol("\tPOP\tD");		/*A08*/
  ol("\tPUSH\tD");		/*A08*/
  }

pp3(pp) int (*pp)(); {                                  /*13*/
  ol("\tPOP\tB");		/*A08*/
  (*pp)();                                              /*13*/
  ol("\tPUSH\tB");		/*A08*/
  }
#endif
