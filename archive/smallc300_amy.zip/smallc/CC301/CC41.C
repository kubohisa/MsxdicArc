/*
** print all assembler info before any code is generated
*/
header()  {
  beglab=getlabel();
                             /*42*/
  }

/*
** print any assembler stuff needed at the end
*/
trailer()  {  
#ifndef LINK
  if((beglab == 1)|(beglab > 9000)) {                  /*51*/
    /* implementation dependent trailer code goes here */
    }
#else
  char *ptr;            /*54*/
  cptr=STARTGLB;                                       /*37*/
  while(cptr<ENDGLB) {                                 /*37*/
    if(cptr[IDENT]==FUNCTION && cptr[CLASS]==AUTOEXT)  /*37*/
      external(cptr+NAME);                             /*37*/
    cptr+=SYMMAX;                                      /*37*/
    }                                                  /*37*/
#ifdef UPPER
  if((ptr=findglb("MAIN")) && (ptr[OFFSET]==FUNCTION)){ /*54*/
#else
  if((ptr=findglb("main")) && (ptr[OFFSET]==FUNCTION)){ /*54*/
#endif
    external("Ulink");  /* link to library functions *//*33*/
#endif

    if(nbflg)			/* return to CCP ? */
       ol("ZZZCCP::\tDB\t1");	/*A08*/
    else			/* normal return   */
       ol("ZZZCCP::\tDB\t0");	/*A08*/
    }
  ol("\tEND");			/*A08*/
  }

/*
** load # args before function call
*/
loadargc(val) int val; {
  if(search("NOCCARGC", macn, NAMESIZE+2, MACNEND, MACNBR, 0)==0) {
    if(val) {                  /*35*/
      ot("\tMVI\tA,");			/*A08*/
      outdec(val);
      nl();
      }                        /*35*/
    else ol("\tXRA\tA");          /*35 A08*/
    }
  }

/*
** declare entry point
*/
entry() {
  outstr(ssname);
  col();
#ifdef LINK
  if(m80flg & m80fnc) col();             /*28*//* fas 2.2 */ /*A13*/
  m80fnc = YES;
#endif
  nl();
  }

/*
** declare external reference
*/
external(name) char *name; {
#ifdef LINK
  ot("\tEXT\t");
  ol(name);
#endif
  }

/*
** fetch object indirect to primary register
*/
indirect(lval) int lval[]; {
  char *sym, indlevel;					/* fas 2.4 */
  sym = lval[0];					/* fas 2.4 */
  indlevel = sym[LEVEL];				/* fas 2.4 */
  if(indlevel){						/* fas 2.4 */
    if(sym[CLASS] == AUTOMATIC) indlevel++;		/* fas 2.4 */ 
    if(level++ >= indlevel && sym[IDENT] == POINTER)	/* fas 2.4 */
      lval[1] = sym[ITYPE];				/* fas 2.4 */
    if(level >= indlevel) explevel = TRUE;		/* fas 2.4 */
    }
  if(lval[1]==CCHAR) ffcall("CCGCHAR##");
  else               ffcall("CCGINT##");
  }

/*
** fetch a static memory cell into primary register
*/
getmem(lval)  int lval[]; {
  char *sym;
  sym=lval[0];
  if((sym[IDENT]!=POINTER)&(sym[TYPE]==CCHAR)) {
    ot("\tLDA\t");			/*A08*/
    outstr(sym+NAME);
    nl();
    ffcall("CCSXT##");
    }
  else {
    ot("\tLHLD\t");			/*A08*/
    outstr(sym+NAME);
    nl();
    }
  }

/*
** fetch addr of the specified symbol into primary register
*/
getloc(sym)  char *sym; {
  const(getint(sym+OFFSET, OFFSIZE)-csp);
  ol("\tDAD\tSP");			/*A08*/
  }

/*
** store primary register into static cell
*/
putmem(lval)  int lval[]; {
  char *sym;
  sym=lval[0];
  if((sym[IDENT]!=POINTER)&(sym[TYPE]==CCHAR)) {
    ol("\tMOV\tA,L");			/*A08*/
    ot("\tSTA\t");			/*A08*/
    }
  else ot("\tSHLD\t");			/*A08*/
  outstr(sym+NAME);
  nl();
  }

/*
** put on the stack the type object in primary register
*/
putstk(lval) int lval[]; {
  char *sym;						/* fas 2.4 */
  if(explevel){						/* fas 2.4 */
    sym = lval[0];					/* fas 2.4 */
    lval[1] = sym[ITYPE];				/* fas 2.4 */
    explevel = 0;					/* fas 2.4 */
    }
  if(lval[1]==CCHAR) {
    ol("\tMOV\tA,L");			/*A08*/
    ol("\tSTAX\tD");			/*A08*/
    }
  else ffcall("CCPINT##");
  }

/*
** move primary register to secondary
*/
move() {
  ol("\tMOV\tD,H");			/*A08*/
  ol("\tMOV\tE,L");			/*A08*/
  }

/*
** swap primary and secondary registers
*/
swap() {
  ol("\tXCHG;;");  /* peephole() uses trailing ";;" A08*/
  }

/*
** swap prim. and sec. registers but don't allow optimizing  fas 2.6
*/
swap2() {
  ol("\tXCHG");			/*A08*/
  }

/*
** partial instruction to get immediate value
** into the primary register
*/
immed() {
  ot("\tLXI\tH,");			/*A08*/
  }

/*
** partial instruction to get immediate operand
** into secondary register
*/
immed2() {
  ot("\tLXI\tD,");			/*A08*/
  }

/*
** push primary register onto stack
*/
push() {
  ol("\tPUSH\tH");			/*A08*/
  csp=csp-BPW;
  }

/*
** unpush or pop as required
*/
smartpop(lval, start) int lval[]; char *start; {
  if(lval[5])  pop(); /* secondary was used */
  else unpush(start);
  }

/*
** replace a push with a swap
*/
unpush(dest) char *dest; {
  int i;
  char *sour;
  sour="\tXCHG;;";  /* peephole() uses trailing ";;" A08*/
  while(*sour) *dest++ = *sour++;
  sour=stagenext;
  while(--sour > dest) { /* adjust stack references */
    if(streq(sour,"\tDAD\tSP")) {			/*A08*/
      --sour;
      i=BPW;
      while(isdigit(*(--sour))) {
        if((*sour = *sour-i) < '0') {
          *sour = *sour+10;
          i=1;
          }
        else i=0;
        }
      }
    }
  csp=csp+BPW;
  }

/*
** pop stack to the secondary register
*/
pop() {
  ol("\tPOP\tD");			/*A08*/
  csp=csp+BPW;
  }

/*
** swap primary register and stack
*/
swapstk() {
  ol("\tXTHL");				/*A08*/
  }

/*
** process switch statement
*/
sw() {
  ffcall("CCSWITCH##");
  }

/*
** call specified subroutine name
*/
ffcall(sname)  char *sname; {
  ot("\tCALL\t");			/*A08*/
  outstr(sname);
  nl();
  }

/*
** return from subroutine
*/
ffret() {
  ol("\tRET");			/*A08*/
  }

/*
** perform subroutine call to value on stack
*/
callstk() {
  ffcall("CCDCAL##");                     /*36*/
  }

/*
** jump to internal label number
*/
jump(label)  int label; {
  ot("\tJMP\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test primary register and jump if false
*/
testjump(label)  int label; {
  ol("\tMOV\tA,H");		/*A08*/
  ol("\tORA\tL");		/*A08*/
  ot("\tJZ\t");			/*A08*/
  printlabel(label);
  nl();
  }

/*
** test primary register against zero and jump if false
*/
zerojump(oper, label, lval) int (*oper)(), label, lval[]; { /*13*/
  clearstage(lval[7], 0);  /* purge conventional code */
  (*oper)(label);                                           /*13*/
  }

/*
** define storage according to size
*/
defstorage(size) int size; {
  if(size==1) ot("\tDB\t");		/*A08*/
  else        ot("\tDW\t");		/*A08*/
  }

/*
** point to following object(s)
*/
point() {
  ol("\tDW\t$+2");			/*A08*/
  }

/*
** modify stack pointer to value given
*/
modstk(newsp, save)  int newsp, save; {
  int k;
  k=newsp-csp;
  if(k==0)return newsp;
  if(k>=0) {
    if(k<7) {
      if(k&1) {
        ol("\tINX\tSP");		/*A08*/
        k--;
        }
      while(k) {
        ol("\tPOP\tB");			/*A08*/
        k=k-BPW;
        }
      return newsp;
      }
    }
  if(k<0) {
    if(k>-7) {
      if(k&1) {
        ol("\tDCX\tSP");		/*A08*/
        k++;
        }
      while(k) {
        ol("\tPUSH\tB");		/*A08*/
        k=k+BPW;
        }
      return newsp;
      }
    }
  if(save) swap();
  const(k);
  ol("\tDAD\tSP");			/*A08*/
  ol("\tSPHL");				/*A08*/
  if(save) swap();
  return newsp;
  }

/*
** double primary register
*/
doublereg() {ol("\tDAD\tH");}		/*A08*/

