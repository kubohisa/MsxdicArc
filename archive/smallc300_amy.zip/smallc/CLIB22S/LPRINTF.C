#define NOCCARGC 
/*
** Yes, that is correct.  Although these functions use an
** argument count, they do not call functions which need one.
*/
#include stdio.h

/*
** lprintf(ctlstring, arg, arg, ...) - Formatted print.
** Operates as described by Kernighan & Ritchie.
** b, c, d, o, s, u, and x specifications are supported.
** Note: b (binary) is a non-standard extension.
**
**      10-Sep-89, FUTURE FORUM
*/

extern char *zzmem;

lprintf(argc)  int argc;    {
        int  *nxtarg;
        nxtarg = CCARGC() + &argc - 1;
        Uprint(1, zzmem, nxtarg);
        while(*zzmem)   putlist(*zzmem++);
        }

