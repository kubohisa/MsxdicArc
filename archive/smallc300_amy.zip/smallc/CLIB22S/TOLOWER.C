/*
** return lower-case of c if upper-case, else c
*/
tolower(c) int c; {
  return(c<='Z' && c>='A' ? c+32 : c);
  }
