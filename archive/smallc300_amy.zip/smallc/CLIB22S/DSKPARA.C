/*      DSKPARA.C       for Small-C
---------------------------------------------------------------------------
        int  dskrem(char drive)

�@�\ ... �f�B�X�N�̎c�ʂ����߂�D
���� ... drive = �h���C�u��  'A' ... 'P'
�o�� ... �c�� (K bytes)
         �܂��� ERR/�G���[

                since  14-Sep-89, (C) FUTURE FORUM
---------------------------------------------------------------------------
        int  dsksize(char drive)

�@�\ ... �f�B�X�N�̑��e�ʂ����߂�D
���� ... drive = �h���C�u��  'A' ... 'P'
�o�� ... �e�� (K bytes)
         �܂��� ERR/�G���[

                since  14-Sep-89, (C) FUTURE FORUM
---------------------------------------------------------------------------
	int  dskdir(char drive)

�@�\ ... �f�B�X�N�̎��^�\�ȃf�B���N�g���������߂�
���� ... drive = �h���C�u��  'A' ... 'P'
�o�� ... �f�B���N�g����
         �܂��� ERR/�G���[

                since  16-Oct-89, (C) FUTURE FORUM
---------------------------------------------------------------------------

*/
#include        <stdio.h>
#define NOCCARGC                /* �����̌���n���Ȃ� */

static char def, drv;
static int block, dsize, unused, ddira,ddirb;

dskrem(c)       char c; {
        c = toupper(c);
        if (c<'A' || c>'P')     return(ERR);
        drv = c - 'A';
        dskpara();
        return(unused);
        }

dsksize(c)      char c; {
        c = toupper(c);
        if (c<'A' || c>'P')     return(ERR);
        drv = c - 'A';
        dskpara();
        return(dsize);
        }

dskdir(c)      char c; {
        c = toupper(c);
        if (c<'A' || c>'P')     return(ERR);
        drv = c - 'A';
        dskpara();
        return(ddira);
        }

/*
        �e��f�B�X�N�E�p�����[�^�����߂�
*/

static dskpara()    {

#asm
bdos    equ     0005h
;
        mvi     c,25
        call    bdos            ;get default drive number
        lxi     h,def
        mov     m,a             ;store default drive number
        lxi     h,drv
        mov     e,m             ;E = drive number
        mvi     c,14
        call    bdos            ;select drive
;
        mvi     c,31
        call    bdos            ;get the top address of DPB
        inx     h
        inx     h
        push    h               ;save DPB address
        mov     a,m             ;Acc = BSH
        dcr     a
        dcr     a
        dcr     a
        mov     l,a
        mvi     h,0
        lxi     d,1
        call    ccasl##         ;HL = DE << HL
        shld    block           ;HL = block size (K bytes)
;
        pop     h               ;get DPB address
        inx     h
        inx     h
        inx     h
;
;----- directory area
	push	h
	inx	h
	inx	h
	mov	e,m
	inx	h
	mov	d,m
	inx	d
	xchg
	shld	ddira		;directory area
;
	xchg
	lxi	h,32
	call	ccdiv##
	shld	ddirb		;directory area (K bytes)
;
	pop	h
        mov     e,m
        inx     h
        mov     d,m             ;DE = DSM
        inx     d               ;DE = DSM + 1
        push    d               ;save disk size (blocks)
        lhld    block
        call    ccmult##
	xchg
	lhld	ddirb
	call	ccsub##
        shld    dsize           ;save disk size (K bytes)
        pop     d
;
        lxi     h,8
        call    ccdiv##         ;HL = DE/8 ... DE
;
        push    d
        push    h
        mvi     c,27
        call    bdos            ;get disk allocation address
;
;--- count unused blocks
        lxi     d,0
dalop1: mvi     b,8
        mov     a,m
dalop2: rlc
        jc      dalop3
        inx     d
dalop3: dcr     b
        jnz     dalop2
        inx     h
        pop     b
        dcx     b
        push    b
        mov     a,b
        ora     c
        jnz     dalop1
;
        pop     b               ;dummy
        pop     b
        mov     a,c
        ora     a
        jz      dalop6
        mov     a,m
dalop4: rlc
        jc      dalop5
        inx     d
dalop5: dcr     c
        jnz     dalop4
;                               ;DE = unused blocks
dalop6: lhld    block
        call    ccmult##
        shld    unused          ;save unused size (K bytes)
;
        lxi     h,def
        mov     e,m
        mvi     c,14
        call    bdos            ;set default drive
#endasm
        }

