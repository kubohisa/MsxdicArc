CP/M Player for Win32
							March 21, 2004

--- What's this

This software is CP/M emulator for Win32.
It is tested on Windows 200 Professional + SP4.
It may work for Windows NT4.0 and Windows 9x but not tested.

Now it is the test release version.
Use at your own risk.


--- How to use

Notice: CP/M system software is not required.

Open CP/M program file (*.com) in the menu "File" - "Open".
(The folder that the selected file belongs to is mounted as drive A:)
The prompt is on the scren, enter the command line and hit return.

You can change settigs (font and screen size) for terminal in "Terminal".
You can select the value returned for BDOS function #12 in "Version".


--- Emulation Status

Z80 core : Implemented
Console : 80x24, Support ANSI and VT-52 ESC Sequence
Drive : Support A-P
BDOS : 0-26, 28-30, 32-37, 40, 110
BIOS : 0-7

Memory Map:
	0x0000 - 0x00ff : Zero Page
	0x0100 - 0xfcff : TPA
	0xfd00 - 0xfdff : CPP (dummy)
	0xfe00 - 0xfeff : BDOS (dummy)
	0xff00 - 0xffff : BIOS (dummy)


--- Credit / Thanks

Z-80 core is based on MAME's Z-80 CPU core.


----------------------------------------
Takeda.Toshiya
t-takeda@m1.interq.or.jp
http://www1.interq.or.jp/~t-takeda/cmp/index.html
http://www1.interq.or.jp/~t-takeda/mz2500/index.html
http://www.emulation9.com/takeda/
