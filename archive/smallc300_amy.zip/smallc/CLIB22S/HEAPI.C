/*      HEAPI.C         for Small-C & Z80CPU
---------------------------------------------------------------------------
        int  heapi(int *ptr, int n)

�@�\ ... ���l�z��̃q�[�v�E�\�[�g
���� ...  ptr   = �z��̐擪�A�h���X
          n     = �z��̌�
�o�� ...  0/����   ERR/�G���[

                since  12-Sep-89, (C) FUTURE FORUM
---------------------------------------------------------------------------
*/
#include        <stdio.h>
#define NOCCARGC                /* �����̌���n���Ȃ� */

heapi(mptr,n)      int *mptr,n; {
        int  l,r,x,*ptr;
        ptr = mptr-1;
        r = n;
        for (l=n/2; l>=1; l--)  {
            x = ptr[l];
            sub(l,r,x,ptr);
            }
        l=1;
        while (r>1)     {
            x = ptr[r];         ptr[r] = ptr[1];
            r--;
            sub(l,r,x,ptr);
            }
        return(0);
        }

static sub(l,r,x,ptr)    int  l,r,x,*ptr;       {
        int  i,j;
        i = l;  j = 2*i;
        while (j<=r)    {
            if (j<r)
                if (ptr[j]<ptr[j+1])   j++;
            if (x>=ptr[j])       break;
                ptr[i] = ptr[j];
                i=j;    j=2*i;
            }
        ptr[i] = x;
        }

