#include        <stdio.h>
#define NOCCARGC  /* no argument count passing */
/*
** Yes, that is correct.  Although these functions use an
** argument count, they do not call functions which need one.
*/
#define   WDMAX   1024          /* �P�ϐ�������̍ő啝 */
#define   BS      8
#define   HTAB    9
#define   SJISA   (-127)        /* &H81 */
#define   SJISB   (-97)         /* &H9F */
#define   SJISC   (-32)         /* &hE0 */
#define   SJISD   (-4)          /* &hFC */

extern char *zzmem;     /* �󂫃G���A�̐擪 */
static char *ctl,       /* ���e�����̃|�C���^ */
            *sch,       /* ���͕�����̃|�C���^ */
            str[17],    /* ����->���l�ϊ��p�o�b�t�@ */
            *carg,      /* �P�������͗p�|�C���^ */
            *sarg,      /* ��������͗p�|�C���^ */
            ch,         /* ���e�����̂P����    ctl + 0 */
            nch,        /*                     ctl + 1 */
            nnch,       /*                     ctl + 2 */
            cc,
            lit,        /* '%'�������� NO */
            kan,        /* ���e�����Ɋ���������ꍇ 1 or 2 */
            nomat,
            unsign,
            skip,       /* '*'���w�肳��Ă��� */
            conv,
            mem,        /* ����������̓��͂��H */
            *zptr,      /* �X�^�b�N�Ď��p */
	    *monout;	/* �W���o�͂ɃG�R�[�o�b�N���邩�ǂ��� */
static int  *narg,      /* ���l���͗p�|�C���^ */
            nn,
            base,
            ac,         /* ��������ϐ��t�B�[���h�̐� */
            width;


/*
** fscanf(fd, ctlstring, arg, arg, ...) - Formatted read.
** Operates as described by Kernighan & Ritchie.
** b, c, d, o, s, u, and x specifications are supported.
** Note: b (binary) is a non-standard extension.
**    modified by  FUTURE FORUM, 07-Sep-89
**		 		 24-Sep-89
*/
fscanf(argc) int argc; {
  int *nxtarg;
  nxtarg = CCARGC() + &argc;
  mem = NO;	monout = NO;
  zptr = &argc - 64;            /* �X�^�b�N�̊m�� */
  return (Uscan(*(--nxtarg), --nxtarg));
  }

/*
** scanf(ctlstring, arg, arg, ...) - Formatted read.
** Operates as described by Kernighan & Ritchie.
** b, c, d, o, s, u, and x specifications are supported.
** Note: b (binary) is a non-standard extension.
**    modified by  FUTURE FORUM, 07-Sep-89
**				 24-Sep-89
*/
scanf(argc) int argc; {
  int  *nxtarg;
  nxtarg = CCARGC() + &argc - 1;
  mem = NO;	monout = YES;
  zptr = &argc - 64;            /* �X�^�b�N�̊m�� */
  return (Uscan(stdin, nxtarg));
  }

/*
** sscanf(str, ctlstring, arg, arg, ...) - Formatted read.
** Operates as described by Kernighan & Ritchie.
** b, c, d, o, s, u, and x specifications are supported.
** Note: b (binary) is a non-standard extension.
**
**    FUTURE FORUM, 07-Sep-89
**		    24-Sep-89
*/
sscanf(argc) int argc; {
  int *nxtarg;
  nxtarg = CCARGC() + &argc;
  mem = YES;	monout = NO;
  zptr = &argc - 64;            /* �X�^�b�N�̊m�� */
  return (Uscan(*(--nxtarg), --nxtarg));
  }

/*
** Uscan(fd, ctlstring, arg, arg, ...) - Formatted read.
** Called by fscanf() ,scanf() and sscanf().
**
**       (C) FUTURE FORUM, since 07-Sep-89
**			   last  23-Sep-89
**�i���Ӂj
**  1) monout = YES �̂Ƃ��C�ǂݍ��񂾃f�[�^�͕W���o�͂ɃG�R�[�o�b
**     �N����܂��D
**  2) �����^�u�͖�������܂��D
**  3) �ǂݍ��񂾃f�[�^�͈�U ZZMEM�ȍ~�̋󂫃G���A�Ƀo�b�t�@�����O
**     ����܂��D
**  4) NEWLINE�̓f�[�^�̏I�[�Ƃ݂Ȃ��C����ȍ~�͓��͂̑ΏۂƂ��܂�
**     ��D�i�W���b�Ƃ͈قȂ�܂��j
**
*/
Uscan(fd, nxtarg)    int  fd, *nxtarg;    {
  sarg = carg = zzmem;                  /* ������̓��� */
  if (mem)    sch = fd;
  cc = NULL;
  while ((cc!=EOF) & (cc!=NEWLINE))    {
    if (carg >= zptr)   return(EOF);    /* �������s�� */
    if (mem)    {
      cc = *sch++;
      if (cc==NULL)    cc = EOF;
      }
    else    cc = fgetc(fd);
    if (cc==HTAB)       continue;       /* �^�u���� */
    if (cc==BS) {                       /* �o�b�N�X�y�[�X���� */
      if (carg > sarg)    {
        carg--;
        putx(BS);    putx(SPACE);    putx(BS);
        carg--;
        if ((carg>=sarg)&(*carg>=SJISA)&(*carg<=SJISB))    {
          carg--;
          putx(BS);    putx(SPACE);    putx(BS);
          }
        if ((carg>=sarg)&(*carg>=SJISC)&(*carg<=SJISD))    {
          carg--;
          putx(BS);    putx(SPACE);    putx(BS);
          }
        carg++;
        }
        continue;
      }
    *carg = cc;    carg++;              /* ���̑� */
    putx(cc);
    }
  carg--;    *carg = NULL;

  ctl = *nxtarg--;              /* �ȉ��C���e�����Ƃ̔�r�E�ϐ��ւ̑�� */
  sch = zzmem;
  nn = 0;     str[0] = NULL;
  ac = 0;     lit = YES;    kan = NO;   skip = NO;  conv = YES;
  ch =Umgetl();

  while((ch!=NULL) & (*sch!=NULL))   {
    while(isspace(*sch))    {
        if (*sch==NULL)  return(ac);
        sch++;
        }
    nch = Umgetl();
    if ((ch=='%') & (!kan) & (lit))    {        /* ���ʕ��� '%'�F�� */
        lit = NO;    ch = nch;    continue;
        }
    if ((ch=='%') & (!kan) & (!lit))      {     /* ���e�����Ƃ��Ă� '%'  */
        lit = YES;
        if (ch != *sch)    return(EOF);
        ch = nch;    sch++;
        continue;
        }

    if (lit)    {                               /* ���e�����̔�r */
        if (ch != *sch)     return(EOF);
        ch = nch;    sch++;
        continue;
        }

    switch(ch)    {                             /* '%' �̎��̕����́H */
        case  '*':    skip = YES;    conv = NO;    sch--;    break;
        case  's':
        case  'c':                  conv = YES;    break;
        case  'b':    base  = 2;  unsign = YES;    conv = YES;    break;
        case  'o':    base  = 8;  unsign = YES;    conv = YES;    break;
        case  'u':    base  =10;  unsign = YES;    conv = YES;    break;
        case  'd':    base  =10;  unsign =  NO;    conv = YES;    break;
        case  'x':    base  =16;  unsign = YES;    conv = YES;    break;
        default:                                /* �ő啝 */
            if (!isdigits(ch))    return(EOF);
            str[nn] = ch;    nn++;
            if (nn>17)    { str[17] = NULL;   nn--; }
            conv = NO;    sch--;
            break;
        }

    if (conv)    {                              /* �ϐ��ւ̊i�[ */
        str[nn] = NULL;                         /* �ő啝�̌v�Z */
        if (str[0]==NULL)       width = WDMAX;
        else                    width = atoi(str);
        nn = 0;    str[0] = NULL;

        switch(ch)    {
          case  'c':                            /* �P���� */
                if (!skip)  { carg = *nxtarg--;  *carg = *sch; ac++;  }
                break;
          case  's':                            /* ������ */
                if (!skip)    sarg = *nxtarg--;
                nomat = YES;    nnch = Umgetl();    ctl--;
                while(width && nomat && (!isspace(*sch)) && (*sch) )  {
                  if (*sch==nch)  {
                        if (kan)  {
                            cc = sch[1];
                            if (cc==nnch)    nomat = NO;
                            }
                        else    nomat = NO;
                        }
                  else if (skip)  sch++;
                  else  {  *sarg = *sch++;      sarg++;  }
                  width--;
                  }
                if (!skip)  { *sarg = NULL;  ac++;  }
                sch--;
                break;
          default:                              /* ���l */
                nomat = YES;    nnch = Umgetl();    ctl--;
                while(width && nomat && (!isspace(*sch)) && (*sch))  {
                  if (*sch==nch)  {
                        if (kan)  {
                            cc = sch[1];
                            if (cc==nnch)    nomat = NO;
                            }
                        else    nomat = NO;
                        }
                  else if (skip)  sch++;
                  else  {  str[nn] = *sch++;    nn++;
                           if (nn>17)  nn--;  }
                  width--;
                  }
                sch--;
                str[nn] = NULL;
                if (!skip)  {
                    narg = *nxtarg--;
                    if (unsign)    *narg = atoib(str,base);
                    else           *narg = atoi(str);
                    ac++;
                    }
                break;
          }

        lit = YES;    conv =YES;  nn = 0;  str[0] = NULL;
        skip = NO;
        }

    ch = nch;    sch++;
    }

    return(ac);
    }

static putx(c)    char c;	{
	if (monout)	fputc(c,stdout);
	}

static Umgetl()        {
        while(isspace(*ctl))    {
            ctl++;
            if (*ctl==NULL)     return(NULL);
            }
        if ((*ctl>=SJISA)&(*ctl<=SJISB))        kan = 2;
        else if ((*ctl>=SJISC)&(*ctl<=SJISD))   kan = 2;
        else if (kan)                           kan--;
        return(*ctl++);
        }
